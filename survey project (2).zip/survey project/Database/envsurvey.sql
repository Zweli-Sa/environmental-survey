-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2021 at 11:00 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `envsurvey`
--

-- --------------------------------------------------------

--
-- Table structure for table `e_addsurveybyfaculty`
--

CREATE TABLE `e_addsurveybyfaculty` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(145) NOT NULL,
  `volunteer` varchar(25) NOT NULL,
  `Date` varchar(25) NOT NULL,
  `venue` varchar(145) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_addsurveybyfaculty`
--

INSERT INTO `e_addsurveybyfaculty` (`id`, `name`, `description`, `volunteer`, `Date`, `venue`) VALUES
(3, 'Covid ', 'Awareness for Covid', '8', '11/8/2021', 'ASIT CENTRE');

-- --------------------------------------------------------

--
-- Table structure for table `e_comp`
--

CREATE TABLE `e_comp` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(245) NOT NULL,
  `volunteer` varchar(25) NOT NULL,
  `date` varchar(45) NOT NULL,
  `venue` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_comp`
--

INSERT INTO `e_comp` (`id`, `name`, `description`, `volunteer`, `date`, `venue`) VALUES
(1, 'Poster Competiton', 'Aware for Air Pollution', '1', '12/02/2020', 'MJ college'),
(2, 'Drawing Competition', 'Draw Drawing of Air Pollution ', '1', '12/14/2020', 'University of Nairobi');

-- --------------------------------------------------------

--
-- Table structure for table `e_compbyfaculty`
--

CREATE TABLE `e_compbyfaculty` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(245) NOT NULL,
  `volunteer` int(11) NOT NULL,
  `date` varchar(45) NOT NULL,
  `venue` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_compbyfaculty`
--

INSERT INTO `e_compbyfaculty` (`id`, `name`, `description`, `volunteer`, `date`, `venue`) VALUES
(1, 'Essay', 'Awareness for Covid', 2, '11/07/2020', 'MJ college'),
(2, 'Essay Seminar', 'Awareness for Covid', 8, '11/13/2020', 'MJ college');

-- --------------------------------------------------------

--
-- Table structure for table `e_faq`
--

CREATE TABLE `e_faq` (
  `id` int(11) NOT NULL,
  `question` varchar(4500) NOT NULL,
  `answer` varchar(4500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_faq`
--

INSERT INTO `e_faq` (`id`, `question`, `answer`) VALUES
(1, 'How to register for the survey?', 'Go to not registered yet? link and register.'),
(2, 'How to participate in the survey?', 'Register for the survey'),
(3, 'How will I be intimated with the new survey?', 'on home screen'),
(4, 'What if it gives error, after participating in the entire survey, and clicked on the submit button at the last for submitting the survey?', 'write to support team'),
(5, 'Why I am unable to participate in the survey? (Two reasons : 1.Not the registered user, and 2.Technical Problem)', 'any of the two problem');

-- --------------------------------------------------------

--
-- Table structure for table `e_paticipation`
--

CREATE TABLE `e_paticipation` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `venue` varchar(45) DEFAULT NULL,
  `volunteers` varchar(20) DEFAULT NULL,
  `dateofseminar` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_paticipation`
--

INSERT INTO `e_paticipation` (`id`, `name`, `venue`, `volunteers`, `dateofseminar`) VALUES
(1, 'Essay Seminar', 'University of Nairobi', '2', '11/06/2020'),
(3, 'Poster Seminar', 'Egerton University', '1', '11/05/2020');

-- --------------------------------------------------------

--
-- Table structure for table `e_submitted`
--

CREATE TABLE `e_submitted` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `totalsurvey` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_submitted`
--

INSERT INTO `e_submitted` (`id`, `name`, `totalsurvey`) VALUES
(1, 'abc', 1),
(2, 'abc', 1),
(3, 'abc', 1),
(20, 'abc', 1);

-- --------------------------------------------------------

--
-- Table structure for table `e_support`
--

CREATE TABLE `e_support` (
  `id` int(11) NOT NULL,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `subject` varchar(245) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_support`
--

INSERT INTO `e_support` (`id`, `fname`, `lname`, `role`, `subject`) VALUES
(1, 'huma', 'khan', 'student', 'site not working'),
(2, 'uzema', 'khan', 'student', 'technical issue'),
(3, 'naushin', 'khan', 'student', 'trouble login');

-- --------------------------------------------------------

--
-- Table structure for table `e_surveyfaculty`
--

CREATE TABLE `e_surveyfaculty` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `volunteer` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL,
  `venue` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_surveyfaculty`
--

INSERT INTO `e_surveyfaculty` (`id`, `name`, `description`, `volunteer`, `date`, `venue`) VALUES
(4, 'Soil pollution', 'Awareness of Soil Pollution', '8', '11/24/2020', 'JKUAT');

-- --------------------------------------------------------

--
-- Table structure for table `e_surveystudent`
--

CREATE TABLE `e_surveystudent` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(145) NOT NULL,
  `volunteer` varchar(25) NOT NULL,
  `Date` varchar(25) NOT NULL,
  `venue` varchar(145) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_surveystudent`
--

INSERT INTO `e_surveystudent` (`id`, `name`, `description`, `volunteer`, `Date`, `venue`) VALUES
(1, 'Pollution', 'Air Pollution causes', '8', '11/28/2020', 'JKUAT');

-- --------------------------------------------------------

--
-- Table structure for table `e_user`
--

CREATE TABLE `e_user` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `roll_no` varchar(25) DEFAULT NULL,
  `class` varchar(45) DEFAULT NULL,
  `specification` varchar(45) DEFAULT NULL,
  `section` varchar(45) DEFAULT NULL,
  `roleid` bigint(20) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `dateofadmission` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `e_user`
--

INSERT INTO `e_user` (`id`, `name`, `roll_no`, `class`, `specification`, `section`, `roleid`, `password`, `status`, `dateofadmission`) VALUES
(30, 'Zweli', '1', 'FE', '09/17/2021', 'A', 3, 'abc', 1, '01/05/2018'),
(34, 'admin', '100', 'se', 'cse', 'B', 1, 'admin123', NULL, '10/02/1994'),
(37, 'Sheeba', '31', 'SE', 'Biotech', 'A', 3, 'khan', 1, '02/03/2017'),
(39, 'Shirin', '12', 'BE', 'PHD', 'A', 2, 'shirin@123', NULL, '01/05/2017'),
(41, 'Naushin', '2', 'BE', 'Biology', 'C', 3, 'khan', 1, '05/02/2018'),
(57, 'Mnqobi', '3', 'TE', 'ACCP', 'C', 3, 'Mnqobi', 1, '09/15/2021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `e_addsurveybyfaculty`
--
ALTER TABLE `e_addsurveybyfaculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_comp`
--
ALTER TABLE `e_comp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_compbyfaculty`
--
ALTER TABLE `e_compbyfaculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_faq`
--
ALTER TABLE `e_faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_paticipation`
--
ALTER TABLE `e_paticipation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_submitted`
--
ALTER TABLE `e_submitted`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_support`
--
ALTER TABLE `e_support`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_surveyfaculty`
--
ALTER TABLE `e_surveyfaculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_surveystudent`
--
ALTER TABLE `e_surveystudent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_user`
--
ALTER TABLE `e_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `e_addsurveybyfaculty`
--
ALTER TABLE `e_addsurveybyfaculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `e_comp`
--
ALTER TABLE `e_comp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `e_compbyfaculty`
--
ALTER TABLE `e_compbyfaculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `e_faq`
--
ALTER TABLE `e_faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `e_paticipation`
--
ALTER TABLE `e_paticipation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `e_submitted`
--
ALTER TABLE `e_submitted`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `e_support`
--
ALTER TABLE `e_support`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `e_surveyfaculty`
--
ALTER TABLE `e_surveyfaculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `e_surveystudent`
--
ALTER TABLE `e_surveystudent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `e_user`
--
ALTER TABLE `e_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
